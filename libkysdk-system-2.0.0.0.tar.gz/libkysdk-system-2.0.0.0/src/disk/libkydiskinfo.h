#ifndef KYSDK_SYSTEM_DISK_INFO_H__
#define KYSDK_SYSTEM_DISK_INFO_H__

#ifdef __cplusplus
extern "C" {
#endif

#define FWREV_SIZE    20

typedef enum _kdk_disk_type{
    DISK_TYPE_HDD,      // 机械
    DISK_TYPE_SSD,      // 固态
    DISK_TYPE_HHD,      // 混合
    DISK_TYPE_FLASH,    // 闪存，比如U盘啥的
    DISK_TYPE_NONE      // 分区盘
}kdk_disk_type;

typedef enum _kdk_disk_interface_type{
    DISK_INTERFACE_SATA,
    DISK_INTERFACE_SATA2,
    DISK_INTERFACE_SATA3,
    DISK_INTERFACE_mSATA,
    DISK_INTERFACE_SAS,
    DISK_INTERFACE_M2,
    DISK_INTERFACE_NVMe,
    DISK_INTERFACE_PCIE,
    DISK_INTERFACE_NONE
}kdk_disk_interface_type;

typedef enum _kdk_disk_format{
    DISK_FMT_UNKNOW,
    DISK_FMT_FAT16,
    DISK_FMT_FAT32,
    DISK_FMT_VFAT,
    DISK_FMT_NTFS,
    DISK_FMT_EXT2,
    DISK_FMT_EXT3,
    DISK_FMT_EXT4,
    DISK_FMT_NONE
}kdk_disk_format;

typedef enum _kdk_disk_partition_type{
    DISK_PART_DISK,     // 基础硬盘
    DISK_PART_MASTER,   // 主分区
    DISK_PART_EXT,      // 扩展分区
    DISK_PART_LOGIC,    // 逻辑分区
    DISK_PART_RAID,     // RAID分区
    DISK_PART_UNKNOW
}kdk_disk_partition_type;

typedef struct _kdk_diskinfo{
    char *name;     // 绝对路径
    char *vendor;   // 制造商
    char *model;    // 型号
    char *serial;   // 序列号

    kdk_disk_type disk_type;  // 磁盘类型，固态 or 机械 or 混合
    kdk_disk_interface_type inter_type;   // 接口类型
    unsigned int rpm;  // 转速，注意固态是没有转速概念的

    unsigned long long sectors_num;   // 扇区数量
    unsigned int sector_size;   // 每个扇区的字节数
    float total_size_MiB;  // 磁盘容量，MiB为单位
    
    unsigned int partition_nums; // 该磁盘/分区下的子分区数量
    char *uuid;     // UUID
    short mounted;   // 是否已挂载
    char *mount_path;   // 挂载路径
    kdk_disk_format format; // 格式化类型
    kdk_disk_partition_type part_type;  // 分区类型
    char *fwrev;    //固件版本信息

}kdk_diskinfo;

/**
 * @brief 获取所有磁盘的列表
 * 
 * @return char**， 每个字符串表示一个磁盘的绝对路径， 结尾以NULL字符表示结束
 */
extern char** kdk_get_disklist();

/**
 * @brief 释放由kdk_get_disklist返回的磁盘列表
 * 
 * @param disklist 由kdk_get_disk_list返回的字符串指针
 */
extern void kdk_free_disklist(char** disklist);


/**
 * @brief 获取指定磁盘的磁盘信息
 * 
 * @param diskname 指定磁盘名称，应当是例如/dev/sda这种绝对路径，或者是disklist中的某个元素
 * @return kdk_diskinfo* 该磁盘的详细信息，具体信息自取
 */
extern kdk_diskinfo *kdk_get_diskinfo(const char *diskname);

/**
 * @brief 释放由kdk_get_diskinfo返回的磁盘信息结构体
 * 
 * @param disk 由kdk_get_diskinfo返回的结构体指针
 */
extern void kdk_free_diskinfo(kdk_diskinfo *disk);

#ifdef __cplusplus
}
#endif

#endif