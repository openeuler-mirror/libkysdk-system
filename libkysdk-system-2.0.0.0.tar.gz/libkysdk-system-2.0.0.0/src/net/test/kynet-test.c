#include "../libkynetinfo.h"
#include "stdio.h"
#include "stdlib.h"

int main(int argc, char *argv[])
{
    prouteMapList list = kdk_net_get_route(), tmp = list;
    while (tmp)
    {
        printf("%s default route %s\n", tmp->name, tmp->addr);
        tmp = list->next;
    }
    kdk_net_free_route(list);
    if (argc < 2)
        printf("please input test port num\n");
    else
        printf("port:%s's state %d\n", argv[1], kdk_net_get_port_stat(atoi(argv[1])));
    
    pChain chain = kdk_net_get_iptable_rules();
    pChain tmpchain = chain;
    while(tmpchain)
    {
        printf("Chain: %s\tpolice: %s\n",tmpchain->total,tmpchain->policy);
        pChainData tmpData = tmpchain->data;
        if(tmpData)
            printf("target: %s\tprot: %s\topt: %s\tsource: %s\tdestination: %s\toption: %s\n",tmpData->target,tmpData->prot,tmpData->opt,
                                tmpData->source,tmpData->destination,tmpData->option);
        printf("\n");
        tmpchain = tmpchain->next;
    }
}