#include <libkysysinfo.hpp>
#include <iostream>
using namespace std;

int main()
{
    cout << "Architecture: "<<KDK_SYSTEM::getSystemArchitecture() << endl;
    cout << "System Name: "<<KDK_SYSTEM::getSystemName()<<endl;
    cout << "Kernel Version: "<< KDK_SYSTEM::getKernelVersion()<<endl;
    cout << "System Version: "<<KDK_SYSTEM::getSystemVersion(false)<<endl;
    cout << "System Version (Verbose): "<<KDK_SYSTEM::getSystemVersion(true)<<endl;
    cout << "Serial Number: "<<KDK_SYSTEM::getSystemSerialNumber() << endl;
    return 0;
}