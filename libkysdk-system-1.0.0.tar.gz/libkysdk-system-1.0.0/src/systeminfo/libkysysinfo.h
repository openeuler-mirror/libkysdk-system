#ifndef KYSDK_SYSTEM_SYSINFO_H__
#define KYSDK_SYSTEM_SYSINFO_H__

/**
 * @file libkysysinfo.h
 * @author liuyunhe (liuyunhe@kylinos.cn)
 * @brief 操作系统基础信息
 * @version 0.1
 * @date 2021-11-02
 * 
 * @copyright Copyright (c) 2021
 * 
 */

#include <string.h>
#include <stdbool.h>

/**
 * @brief 获取操作系统架构信息
 * 
 * @return char* 
 */
extern char* kdk_system_get_architecture();

/**
 * @brief 获取操作系统名称
 * 
 * @return char* 
 */
extern char* kdk_system_get_systemName();

/**
 * @brief 获取操作系统版本号
 * 
 * @param verbose 0获取简略版本号，1获取详细版本号
 * @return char* 
 */
extern char* kdk_system_get_version(bool verbose);

/**
 * @brief 获取操作系统激活状态
 * 
 * @return true 
 * @return false 
 */
extern bool kdk_system_get_activationStatus();

/**
 * @brief 获取操作系统服务序列号
 * 
 * @return char* 
 */
extern char* kdk_system_get_serialNumber();

/**
 * @brief 获取内核版本号
 * 
 * @return char* 
 */
extern char* kdk_system_get_kernelVersion();

/**
 * @brief 获取当前登录用户的用户名
 * 
 * @return char* 
 */
extern char* kdk_system_get_currentUser();

#endif  // KYSDK_SYSTEM_SYSINFO_H__