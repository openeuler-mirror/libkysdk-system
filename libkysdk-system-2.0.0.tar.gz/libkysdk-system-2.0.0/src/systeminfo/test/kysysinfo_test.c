#include <libkysysinfo.h>
#include <stdio.h>
#include <stdlib.h>

int main()
{
    char *res = kdk_system_get_architecture();
    printf("架构：%s\n", res);
    free(res);
    res = kdk_system_get_systemName();
    printf("系统名称：%s\n", res);
    free(res);
    res = kdk_system_get_version(0);
    printf("系统简略版本：%s\n", res);
    free(res);
    res = kdk_system_get_version(1);
    printf("系统详细版本：%s\n", res);
    free(res);
    res = kdk_system_get_kernelVersion();
    printf("内核版本：%s\n", res);
    free(res);
    res = kdk_system_get_serialNumber();
    printf("序列号：%s\n", res);
    free(res);
    int p;
    int d;
    int act = kdk_system_get_activationStatus(&p,&d);
    printf("--------------\n");
    printf("激活状态码：%d\n",act);
    printf("激活状态：%s\n", act == 1 ? "已激活" : act == 0 ? "未激活" : "已过期");

    res = kdk_system_get_eUser();
    printf("当前用户：%s\n", res);
    free(res);

    res = kdk_system_get_projectName();
    printf("项目编号名：%s\n", res);
    free(res);
    int zyj = kdk_system_is_zyj();
    printf("专用机：%s\n", zyj == 0 ? "非专用机":"专用机");

    res = kdk_system_get_hostVirtType();
    printf("虚拟机类型：%s\n", res);
    free(res);

    res = kdk_system_get_hostCloudPlatform();
    printf("云平台类型：%s\n", res);
    free(res);

    version_t test = kdk_system_get_version_detaile( );
    printf("test.os_version = %s\n",test.os_version);
    printf("test.update_version = %s\n",test.update_version);

    char** name = kdk_system_get_resolving_power();
    // printf("name = %s\n", name);
    size_t count = 0;
    while (name[count])
    {
        printf("No. %d\t %s\n", count + 1, name[count]);
        count ++;
    }
    kdk_resolving_freeall(name);

    return 0;
}